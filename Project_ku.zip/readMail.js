var nodemailer = require("nodemailer")

var transporter = nodemailer.createTransport({
    service : "hotmail",
    auth : {
        user : "preetha.c2000@outlook.com",
        pass : "Meow@2000."
    }
});

const portalURL = "https://klyuniv.ac.in/"
const supportEmail ="supportcbcs@klyuniv.ac.in"
const supportPhoneNumber ="+91 8637223454"

send = function sendMail(mailId,myFname,myLname, password){
    const mailOptions = {
        from : 'preetha.c2000@outlook.com',
        to : mailId,
        subject : 'KU CBCS Registration Password',
        html: `
        <p>Dear ${myFname} ${myLname}</p>
        <p>I hope this email finds you well. We are pleased to inform you that your admission registration for University of Kalyani CBCS has been successfully processed. As part of the confirmation process, we are providing you with your login credentials to access the admission portal.</p>
        
        <p>Below are your login details:</p>
        <p>Username: ${mailId}</p>
        <p>Password: ${password}</p>
  
        <p>To access CBCS portal, please visit <a href="${portalURL}">${portalURL}</a> and log in using the provided credentials. If you encounter any issues or have questions regarding the CBCS process, feel free to reach out to our support team at ${supportEmail} or ${supportPhoneNumber}.</p>
  
        <p>It is essential to keep your login credentials confidential to ensure the security of your personal information. Wish you success in your academic journey.</p>
  
        <p>Best regards,<br>
        University of Kalyani<br>
        Kalyani,Nadia</p>
      `,
    };

    transporter.sendMail(mailOptions , function(err , info){
        if(err){
            console.log(err);
            return;
        }
        console.log("sent" + info.response)
    });
}
module.exports = send;
