pass = function generatePassword(){
    math = require("mathjs");
    //var pass = "CBCS-";
    var code = math.random().toString(36).slice(-6).toUpperCase();
    var otp = code;

    return otp;
}

module.exports = pass;