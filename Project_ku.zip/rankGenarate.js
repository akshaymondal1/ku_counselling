const connection = require('./dbConnect')

genarate = function rankGenarate(req,res) {
  // Fetch data from database and sort by marks
  const fields = req.query.fields ? req.query.fields : '*';
  // const cond = 'g_percent';
  // http://localhost:3000/rankGenarate?fields=pg_sgpa
  const sql = `SELECT email, pg_sgpa FROM student_details ORDER BY ${fields} DESC`;
  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching data: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Update 'update' column with corresponding ranks
    let rank = 1;
    for (const result of results) {
      connection.query('UPDATE student_details SET rank = ? WHERE email = ?', [rank, result.email], (updateErr) => {
        if (updateErr) {
          console.error('Error updating rank: ' + updateErr.stack);
          res.status(500).send('Internal Server Error');
          return;
        }
      });
      rank++;
    }

    res.send('Ranks updated successfully!');
  });
};

module.exports = genarate;
