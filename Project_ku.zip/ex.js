const express = require('express');
const mysql = require('mysql');
const ExcelJS = require('exceljs');
const app = express();
const port = 3000;

// MySQL Connection Configuration
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'counselling'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

// Route to fetch data from MySQL and generate Excel
app.get('/generate-excel', (req, res) => {
  // Fetch data from MySQL
  const sql = 'SELECT student_registration.id, student_registration.first_name,student_registration.last_name,student_registration.course,student_registration.email,student_registration.mobile_number,subjects.name FROM student_registration JOIN sub_allocation ON student_registration.email = sub_allocation.email JOIN subjects ON sub_allocation.subject_id = subjects.id ORDER BY name'; 

  connection.query(sql, (error, results, fields) => {
    if (error) {
      console.error('Error fetching data from MySQL: ' + error.stack);
      return res.status(500).send('Error fetching data from MySQL');
    }

    // Create a new Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Data');

    // Add column headers
    const columns = [
        { header: 'ID', key: 'id', width: 15 },
      { header: 'First Name', key: 'first_name', width: 15 },
      { header: 'Last Name', key: 'last_name', width: 15 },
      { header: 'Department', key: 'course', width: 30 },
      { header: 'Email', key: 'email', width: 30 },
      { header: 'Phone No.', key: 'mobile_number', width: 30 },
      { header: 'CBCS Course', key: 'name', width: 25 },
    ];
    // for (const field of fields) {
    //   columns.push({ header: field.name, key: field.name, width: 15 });
    // }
    worksheet.columns = columns;

    // Add rows of data
    for (const row of results) {
      worksheet.addRow(row);
    }

    // Generate Excel file
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="data.xlsx"');

    workbook.xlsx.write(res)
      .then(() => {
        res.end();
      })
      .catch((err) => {
        console.error('Error generating Excel: ' + err.stack);
        res.status(500).send('Error generating Excel');
      });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
