var nodemailer = require("nodemailer")
var XLSX = require("xlsx");
var workbook = XLSX.readFile("Book1.xlsx");
var transporter = nodemailer.createTransport({
    service : "hotmail",
    auth : {
        user : "preetha.c2000@outlook.com",
        pass : "Meow@2000."
    }
});

let worksheet = workbook.Sheets[workbook.SheetNames[0]]; 

for (let index = 2;index < 5; index ++){
    const mail = worksheet[`A${index}`].v;

    console.log({
        mail:mail
    });

    var password = generatePassword();

    const mailOptions = {
        from : 'preetha.c2000@outlook.com',
        to : mail,
        subject : 'Test mail',
        text : "Login to fill up the application form using the following password -->  " + password + " ."
    };

    transporter.sendMail(mailOptions , function(err , info){
        if(err){
            console.log(err);
            return;
        }
        console.log("sent" + info.response)
    });

};

function generatePassword(){
    math = require("mathjs")
    var pass = "CBCS-"
    var code = math.random().toString(36).slice(-5).toUpperCase()
    var otp = pass + code

    return otp;
};