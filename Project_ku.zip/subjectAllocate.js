const db = require('./dbConnect');


allocate = function subAlloc(req, res){
    const getAllStudents = 'SELECT email, first_pref, second_pref, third_pref FROM student_details ORDER BY rank ASC';

    db.query(getAllStudents, (err, students) => {
        if (err) throw err;

        // Loop through each student
        students.forEach((student) => {
            allocateSubjectsForStudent(student);
        });

        res.json({ message: 'Allocation process completed for all students' });
    });
};

function allocateSubjectsForStudent(student) {
    const studentId = student.email;
    const firstPref = student.first_pref;
    const secondPref = student.second_pref;
    const thirdPref = student.third_pref;

    // Allocate subjects based on marks
    checkAvl(firstPref, () => {
        allocateSubject(firstPref, studentId);
    }, () => {
        checkAvl(secondPref, () => {
            allocateSubject(secondPref, studentId);
        }, () => {
            checkAvl(thirdPref, () => {
                allocateSubject(thirdPref, studentId);
            }, () => {
                   const pending_sql = "INSERT INTO not_sub_alloc(email) VALUES (?)";
                    const VALUES =[studentId]
                db.query(pending_sql,VALUES, (err, results) => {
                    if (err) {
                      console.error('MySQL query error:', err);
                      res.status(500).send('Internal server error');
                    } else {
                        console.log(`No available subjects for student with ID ${studentId}`);
                    }
                  });
                
            });
        });
    });
}

// Check avilable seat or not
function checkAvl(subjectType, successCallback, errorCallback) {
    const getSubjectId = 'SELECT id, available_seats FROM subjects WHERE name = ?';
    db.query(getSubjectId, [subjectType], (err, results) => {
        if (err) throw err;

        const availableSeats = results[0].available_seats;

        if (availableSeats > 0) {
            console.log("Subject available");
            successCallback();
        } else {
            console.log('No available seats for:', subjectType);
            errorCallback();
        }
    });
}

// Function to allocate subject based on available seats
function allocateSubject(subjectType, studentId) {
    const getSubjectId = 'SELECT id, available_seats FROM subjects WHERE name = ?';
    db.query(getSubjectId, [subjectType], (err, results) => {
        if (err) throw err;

        const subjectId = results[0].id;
        // const subName = results[0].name;
        const availableSeats = results[0].available_seats;

        if (availableSeats > 0) {
            // Decrement available seats
            const updateSeats = 'UPDATE subjects SET available_seats = ? WHERE id = ?';
            db.query(updateSeats, [availableSeats - 1, subjectId], (err) => {
                if (err) throw err;

                // Save allocation in the database
                const saveAllocation = 'INSERT INTO sub_allocation (email, subject_id) VALUES (?, ?)';
                db.query(saveAllocation, [studentId, subjectId], (err) => {
                    if (err) throw err;
                    console.log('Subject allocated:', subjectType);
                    // res.end({ message: 'Subject allocated successfully'+subjectType });
                });
            });
        } else {
            console.log('No available seats for:', subjectType);
            res.json({ message: 'No available seats for ' + subjectType });
        }
    });
}

module.exports = allocate;
