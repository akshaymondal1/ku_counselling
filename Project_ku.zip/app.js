const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const session = require('express-session');
const db = require('./dbConnect');
const send = require('./readMail.js');
const allocate = require('./subjectAllocate.js');
const genarate = require('./rankGenarate.js')
const pass = require('./password.js');
const b_crypt = require('bcrypt');
app.use(express.static('public'));
const log = require('./stuLogin');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const ExcelJS = require('exceljs')
const mysql = require('mysql2');

var user_name = "";
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views'); 
const port = 3000;


//session
const sessionSecret = process.env.SESSION_SECRET || 'fallback-secret-key';

app.use(session({
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
}));



// Middleware to prevent page caching
app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});


// Parse incoming data as JSON
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//index
app.get('/',(req,res)=>{
    res.render('index')
})

app.get('/index',(req,res)=>{
    res.render('index')
})
//Login page rout
app.get('/studentLogin',(req,res)=>{
    res.render('studentLogin')
})

//Login page rout
app.get('/viewDetails',(req,res)=>{
    res.render('viewDetails')
})

// Check if subject is already allocated
app.get('/alloc', (req, res) => {
  // Example SQL query to check if subject allocate
  const sql = 'SELECT email FROM sub_allocation WHERE email IS NOT NULL LIMIT 1';

  db.query(sql, (err, result) => {
    if (err) {
      console.error('Error checking rank: ' + err.message);
      res.status(500).send('Error checking rank');
      return;
    }

    // If rank is already generated, send response indicating so
    if (result.length > 0) {
      res.json({ subAlloc: true });
    } else {
      res.json({ subAlloc: false });
    }
  });
});

//Student registration page routing
app.get('/studentRegistration',(req,res)=>{
    res.render('studentRegistration')
})


//admin page pending student
app.get('/applicantDetails',(req,res)=>{
    if(req.session.loggedin){
        const sql = 'SELECT student_registration.*, student_details.*FROM student_registration INNER JOIN student_details ON student_registration.email = student_details.email';
        db.query(sql, (err, results) => {
        if (err) {
            console.error('MySQL query error:', err);
            res.status(500).send('Internal server error');
        } else {
            res.render('applicantDetails', { students: results });
        }
        });
    }
    else{
      res.render('adminLogin')
    }
  })

//admin page pending student
app.get('/acceptedApplicants',(req,res)=>{

    if(req.session.loggedin){
        const sql = 'SELECT * FROM student_registration JOIN sub_allocation ON student_registration.email = sub_allocation.email JOIN subjects ON sub_allocation.subject_id = subjects.id ORDER BY name';
        db.query(sql, (err, results) => {
        if (err) {
            console.error('MySQL query error:', err);
            res.status(500).send('Internal server error');
        } else {
            console.log(results)
            res.render('acceptedApplicants', { students: results });
        }
        });
    }
    else{
      res.render('adminLogin')
        }
  })

//admin page pending student
app.get('/pendingApplicant',(req,res)=>{

    if (req.session.loggedin) {
    const sql = 'SELECT * FROM student_registration JOIN not_sub_alloc ON student_registration.email = not_sub_alloc.email JOIN student_details ON not_sub_alloc.email= student_details.email';

    db.query(sql, (err, results) => {
      if (err) {
        console.error('MySQL query error:', err);
        res.status(500).send('Internal server error');
      } else {
        console.log(results)
        res.render('pendingApplicant', { students: results });
      }
    });
}
else{
  res.render('adminLogin')
}

  })

//Admin login page render
app.get('/adminLogin',(req,res)=>{
    res.render('adminLogin')
})

app.get('/subAllocate',(req,res)=>{
   allocate(req,res);
})

app.get('/rankGenarate',(req,res)=>{
    genarate(req,res);
 })

//Admin home get function
app.get('/adminhome',(req,res)=>{
    if (req.session.loggedin) {
        // Query to count number of entries
        const sql = `
        SELECT
          (SELECT COUNT(*) FROM not_sub_alloc) AS count_table1,
          (SELECT COUNT(*) FROM sub_allocation) AS count_table2;
      `;

  // Execute query
  db.query(sql, (err, result) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      return res.status(500).json({ error: 'Database error' });
    }

     // Extract counts from the results
    const countTable1 = result[0].count_table1;
    const countTable2 = result[0].count_table2;

    // Render the EJS view and pass the count as a variable
    res.render('adminhome',{ username: req.session.username,count1: countTable1, count2:countTable2});
  });
   
    }
    else{
      res.render('adminLogin')
    }
})

//Admin home get function
app.get('/counProcess',(req,res)=>{
  if (req.session.loggedin) {
  res.render('counProcess',{ username: req.session.username })
  }
  else{
    res.render('adminLogin')
  }
})

//Admin login code
app.post('/adminLogin',(req,res)=> {
    const username = req.body.username;
    const password = req.body.password;

    user_name = username;

    db.query('SELECT * FROM admin WHERE userid = ? ',[username], async(error,results,fields) =>{
        const is_match = await b_crypt.compare(password,results[0].password);
        if (is_match) {
        
            //db.query('SELECT * FROM student_registration WHERE first_name = ? AND Password = ?', [username, password], (error, results, fields) => {
                if (password.length > 0) {
                    req.session.loggedin = true;
                    req.session.username = username;
        
                    res.redirect('/adminhome');
                    //res.render('adminhome' , { username: req.session.username });
                    console.log(req.body);
                    
                } else {
                    res.send('Incorrect username and/or password.');
                }
                res.end();
            //}
            //);
        } else {
            res.send('Please enter username and password.');
            res.end();
        }
    });
})

// Route to fetch data from MySQL and generate Excel
app.get('/generate-excel', (req, res) => {
    // Fetch data from MySQL
    const sql = 'SELECT student_registration.id, student_registration.first_name,student_registration.last_name,student_registration.course,student_registration.email,student_registration.mobile_number,subjects.name FROM student_registration JOIN sub_allocation ON student_registration.email = sub_allocation.email JOIN subjects ON sub_allocation.subject_id = subjects.id ORDER BY name'; 
  
    db.query(sql, (error, results, fields) => {
      if (error) {
        console.error('Error fetching data from MySQL: ' + error.stack);
        return res.status(500).send('Error fetching data from MySQL');
      }
  
      // Create a new Excel workbook
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Data');
  
      // Add column headers
      const columns = [
          { header: 'ID', key: 'id', width: 15 },
        { header: 'First Name', key: 'first_name', width: 15 },
        { header: 'Last Name', key: 'last_name', width: 15 },
        { header: 'Department', key: 'course', width: 30 },
        { header: 'Email', key: 'email', width: 30 },
        { header: 'Phone No.', key: 'mobile_number', width: 30 },
        { header: 'CBCS Course', key: 'name', width: 25 },
      ];
      // for (const field of fields) {
      //   columns.push({ header: field.name, key: field.name, width: 15 });
      // }
      worksheet.columns = columns;
  
      // Add rows of data
      for (const row of results) {
        worksheet.addRow(row);
      }
  
      // Generate Excel file
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="data.xlsx"');
  
      workbook.xlsx.write(res)
        .then(() => {
          res.end();
        })
        .catch((err) => {
          console.error('Error generating Excel: ' + err.stack);
          res.status(500).send('Error generating Excel');
        });
    });
  });



// Route to handle PDF download
app.get('/generate_pdf', (req, res) => {
  // Create a new PDF document
  const doc = new PDFDocument();

  // Set content disposition to attachment to force download
  res.setHeader('Content-Disposition', 'attachment; filename="select_student_list.pdf"');

  // Pipe the PDF to the response stream
  doc.pipe(res);

    const sql = 'SELECT student_registration.id, student_registration.first_name,student_registration.last_name,student_registration.course,student_registration.email,subjects.name FROM student_registration JOIN sub_allocation ON student_registration.email = sub_allocation.email JOIN subjects ON sub_allocation.subject_id = subjects.id ORDER BY name';

    // Query data from MySQL
    db.query(sql, (error, results, fields) => {
      if (error) {
        console.error('Error querying MySQL database: ' + error.stack);
        return res.status(500).send('Error querying database');
      }

      const head = ['Id',
                    'First Name',
                    'Last Name',
                    'Department',
                    'Email',
                    'CBCS Course',
                    'Phone No'
                    ]
      // Set table properties
      const tableTop = 70;
      const tableLeft = 5;
      const rowHeight = 25;
      const columnWidth = 100;
      
      let yPosition = tableTop;
      let xPosition = tableLeft
    
    //   doc.font('Times-Roman').fontSize(20).text('University of Kalyani', 100, 10);
      doc.font('Helvetica-Bold').fontSize(20).text('Selected Student List for CBCS programm', 100, 15);

      head.forEach((data)=>{
        doc.font('Helvetica-Bold').fontSize(10).text(data.toString(), xPosition, yPosition+5, { width: columnWidth, align: 'center' });
          xPosition += columnWidth;
      })
      yPosition += rowHeight
     
        doc.moveTo(5,yPosition)
            .lineTo(xPosition,yPosition)
            .stroke()  
     
      // Iterate through rows of MySQL data
      results.forEach(row => {
        let xPosition = tableLeft;
        // Draw cells for each column
        Object.values(row).forEach(value => {
          doc.font('Helvetica').fontSize(8).text(value.toString(), xPosition, yPosition+5, { width: columnWidth, align: 'center' });
          xPosition += columnWidth;
        });

        
        // Draw line after each row
        drawLine(doc, tableLeft, yPosition + rowHeight, tableLeft + Object.keys(row).length * columnWidth, yPosition + rowHeight);
        // Move to next row position
        yPosition += rowHeight;
      });

      // Finalize the PDF
      doc.end();
    });
  });

// Function to draw a line
function drawLine(doc, startX, startY, endX, endY) {
  doc.moveTo(startX, startY).lineTo(endX, endY).stroke();
}



//dashbord after Student login routing 
app.get('/studentHome', (req, res) => {
    user_name = req.session.username 
   db.query('SELECT * FROM student_registration WHERE email = ? ',[user_name], async(error,results,fields) =>{
       res.render('studentHome', {studentData:results[0]}); 
   })
});


//Student Details after Student Home
app.get('/studentDetails' , (req,res) => {
    db.query('SELECT * FROM student_registration WHERE email = ? ',[user_name], (error,results,fields) => {
        res.render('studentDetails' , {studentData:results[0]});
    })
    console.log(user_name);
});


//Regisrtation page data saved routing
app.post('/regSave', async(req, res) => {
    const data = req.body;
    const password = pass();
    const hash = await b_crypt.hash(password,10);
    const sql = 'INSERT INTO student_registration (first_name, last_name, email, mobile_number, application_id, registration_id, date_of_birth, gender, department, course, Password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
    const values = [
        data.myFname,
        data.myLname,
        data.myEmail,
        data.myMobileNumber,
        data.myApplicationId,
        data.myRegistrationId,
        data.myDateOfBirth,
        data.Gender,
        data.Department,
        data.Course,
        hash,
    ];

    send(data.myEmail,data.myFname,data.myLname,password);

    db.query(sql, values, (error, results) => {
        if (error) {
            console.error('Database query error: ' + error.message);
            res.status(500).send('Error saving data to the database');
        } else {
            console.log('Data saved to the database');
            res.render('studentLogin');
        }
    });
})

//Login
app.post('/studentHome', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    user_name = username;

    db.query('SELECT * FROM student_registration WHERE email = ? ',[username], async(error,results,fields) =>{
        const is_match = await b_crypt.compare(password,results[0].Password);
        if (is_match) {
        
            //db.query('SELECT * FROM student_registration WHERE first_name = ? AND Password = ?', [username, password], (error, results, fields) => {
                if (password.length > 0) {
                    req.session.loggedin = true;
                    req.session.username = username;
        
                    //res.redirect('/dashboard');
                    res.render('studentHome' , {studentData:results[0]});
                    console.log(req.body);
                    
                } else {
                    res.send('Incorrect username and/or password.');
                }
                res.end();
            //}
            //);
        } else {
            res.send('Please enter username and password.');
            res.end();
        }
    });
});

//Student Details
app.post('/saveStudentDetails' , (req,res) => {
    console.log(user_name);
    const data2 = req.body;

    console.log(req.body);
    const sql2 = 'INSERT INTO student_details (email , s_board , s_percent , s_yop , hs_board , hs_percent , hs_yop , g_board , g_percent , g_yop , pg_department , pg_course , pg_sgpa , first_pref , second_pref , third_pref) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    const values2 = [
        user_name,
        data2.sBoard,
        data2.sPercent,
        data2.sYOP,
        data2.hsBoard,
        data2.hsPercent,
        data2.hsYOP,
        data2.gBoard,
        data2.gPercent,
        data2.gYOP,
        data2.Department,
        data2.Course,
        data2.pgSGPA,
        data2.firstPreference,
        data2.secondPreference,
        data2.thirdPreference,
    ];
    db.query(sql2, values2, (error, results) => {
        if (error) {
            console.error('Database query error: ' + error.message);
            res.status(500).send('Error saving data to the database');
        } else {
            console.log('Student Data saved to the database');
            db.query('SELECT * FROM student_registration WHERE email = ? ',[user_name], (error,results,fields) =>{
                res.render('studentHome' , {studentData:results[0]});
            })
            
        }
    });

});


//Logout
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).send('Error while logging out');
      }
       // Clearing the session and setting headers to prevent caching
       res.clearCookie('connect.sid');
       res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
       res.setHeader('Pragma', 'no-cache');
       res.setHeader('Expires', '0');
    //    res.send('Logged out successfully');
      // Redirect or send a response indicating successful logout
      res.redirect('/index');
    });
  });
  
  

//Server run
app.listen(port, () => {
    console.log('Server is running on port ');
});
