const db = require('./dbConnect');
const b_crypt = require('bcrypt');

log = function loginCd (req, res){
    const username = req.body.username;
    const password = req.body.password;

    db.query('SELECT * FROM student_registration WHERE email = ? ',[username], async(error,results,fields) =>{
        const is_match = await b_crypt.compare(password,results[0].Password);
        if (is_match) {
        
            //db.query('SELECT * FROM student_registration WHERE first_name = ? AND Password = ?', [username, password], (error, results, fields) => {
                if (password.length > 0) {
                    req.session.loggedin = true;
                    req.session.username = username;
        
                    //res.redirect('/dashboard');
                    res.render('studentHome' , {studentData:results[0]});
                    console.log(req.body);
                    
                } else {
                    res.send('Incorrect username and/or password.');
                }
                res.end();
            //}
            //);
        } else {
            res.send('Please enter username and password.');
            res.end();
        }
    });
};

module.exports = log;