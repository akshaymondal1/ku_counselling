const db = require('./dbConnect');
admin_login = function admin_login(req,res){
    const { username, password } = req.body;
  
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
  
    const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
  
    db.query(sql, [username, password], (err, results) => {
      if (err) {
        console.error('MySQL query error:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
  
      if (results.length > 0) {
        // User authenticated successfully
        res.json({ message: 'Login successful' });
      } else {
        // Invalid credentials
        res.status(401).json({ message: 'Invalid username or password' });
      }
    });
  }